import { Entity, Column,OneToMany, ManyToOne,  } from 'typeorm';
import { RecapitiEntity } from '../recapiti/recapiti.entity';
import { BaseEntityIncrement } from 'src/baseEntities/baseIncrement.entity';
import { SocietaEntity } from 'src/societa/societa.entity';
import { StreamableFile } from '@nestjs/common';

@Entity()
export class PdfEntity extends BaseEntityIncrement{

  @Column()
  nomeFile: string;

  @Column()
  dir: string;

  @Column()
  tipoFile: string;

}

  
