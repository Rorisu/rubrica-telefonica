import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RecapitiEntity } from 'src/recapiti/recapiti.entity';
import { TipoEntity } from 'src/tipo/tipo.entity';
import { UserController } from './user.controller';
import { UserEntity } from './user.entity';
import { UserService } from './user.service';
import { SocietaEntity } from 'src/societa/societa.entity';
import { PdfEntity } from 'src/pdf/pdf.entity';
import { IndirizzoEntity } from 'src/indirizzo/indirizzo.entity';

@Module({
  providers: [UserService],
  controllers:[UserController],
  imports:[
    TypeOrmModule.forFeature([
      UserEntity,
      RecapitiEntity,
      TipoEntity,
      SocietaEntity,
      PdfEntity,
      IndirizzoEntity
    ])]
})
export class UserModule {}
