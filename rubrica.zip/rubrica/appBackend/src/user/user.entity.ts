import { Entity, Column,OneToMany, ManyToOne, OneToOne, JoinColumn,  } from 'typeorm';
import { RecapitiEntity } from '../recapiti/recapiti.entity';
import { BaseEntityIncrement } from 'src/baseEntities/baseIncrement.entity';
import { SocietaEntity } from 'src/societa/societa.entity';
import { IndirizzoEntity } from 'src/indirizzo/indirizzo.entity';

@Entity()
export class UserEntity extends BaseEntityIncrement{


  @Column()
  nome: string;

  @Column()
  cognome: string;   
  
  @Column()
  data: Date;

  @Column()
  update: Date;
  

  @OneToMany(() => RecapitiEntity, (obj) => obj.user)
  recapiti: UserEntity[]

  @ManyToOne(() => SocietaEntity) 
  societa: SocietaEntity;

  @OneToMany(() => IndirizzoEntity, (obj) => obj.user)
  indirizzo: IndirizzoEntity[];
}

  
