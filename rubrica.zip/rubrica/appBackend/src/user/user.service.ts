import { Injectable, OnModuleInit, Post, UploadedFile, UseInterceptors } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { RecapitiEntity } from 'src/recapiti/recapiti.entity';
import { TipoEntity } from 'src/tipo/tipo.entity';
import { Repository } from 'typeorm';
import { UserEntity } from './user.entity';
import { RecapitiDto } from 'src/recapiti/recapiti.dto';
import { UserDTO } from './user.dto';
import { SocietaEntity } from 'src/societa/societa.entity';
import * as moment from 'moment';
import { PdfEntity } from 'src/pdf/pdf.entity';
const PDFDocument = require("pdfkit-table");
const fs = require('fs');
const blobStream = require('blob-stream');
import { v4 as uuidv4 } from 'uuid';
import { IndirizzoDTO } from 'src/indirizzo/indirizzo.dto';
import { IndirizzoEntity } from 'src/indirizzo/indirizzo.entity';
uuidv4();
const ExcelJS = require('exceljs');

@Injectable()
export class UserService implements OnModuleInit {

    private data;

    onModuleInit() {

        this.createTipo();
        this.insertSocieta();

    }

    //creo una repository così da poter fare azioni sulla tabella
    constructor(

        @InjectRepository(UserEntity)
        private usersRepository: Repository<UserEntity>,

        @InjectRepository(RecapitiEntity)
        private recapitiRepository: Repository<RecapitiEntity>,

        @InjectRepository(TipoEntity)
        private tipoRepository: Repository<TipoEntity>,

        @InjectRepository(SocietaEntity)
        private societaRepository: Repository<SocietaEntity>,

        @InjectRepository(PdfEntity)
        private pdfRepository: Repository<PdfEntity>,

        @InjectRepository(IndirizzoEntity)
        private indirizzoRepository: Repository<IndirizzoEntity>

    ) {

    }

    @Post()

    //inserimento dati
    async create(body: UserDTO) {

        if (body) {

            const singoloUser = {

                nome: body.nome,
                cognome: body.cognome,
                data: new Date(),
                update: new Date(),
                societa: {
                    id: this.getSocietaId(body.societa),
                }

            }
            console.log(singoloUser);
            await this.usersRepository.manager.save(UserEntity, singoloUser);

        }
    }

    //select di tutta la tabella
    async findAll(body: any) {

        body.skip *= 50
        if (body.ricerca != '') {

            return await this.search(body);

        } else {
            this.data = this.usersRepository.find({

                relations: [

                    'recapiti', 'recapiti.tipo', 'societa'
                ],

                take: 50, skip: body.skip, order: { id: 'asc' }
            })

            return this.data;
        }

    }

    count() {

        return this.usersRepository.count({});

    }

    findTipi() {

        return this.tipoRepository.find({
            select: {
                valore: true
            }
        })

    }

    getSocieta() {

        return this.societaRepository.find({

            select: {

                valore: true

            }

        })

    }

    async createTipo() {

        const tipo = [

            {
                id: 1,
                valore: "Numero Cellulare"
            },
            {
                id: 2,
                valore: "Numero Fisso"
            },
            {
                id: 3,
                valore: "Fax ufficio"
            },
            {
                id: 4,
                valore: "Email"
            },
            {
                id: 5,
                valore: "Fax casa"
            }


        ]

        await this.tipoRepository.manager.save(TipoEntity, tipo);

    }

    async insertSocieta() {

        const societa = [

            {
                id: 1,
                valore: "Amazon"
            },
            {
                id: 2,
                valore: "Google"
            },
            {
                id: 3,
                valore: "Meta"
            },
            {
                id: 4,
                valore: "Apple"
            },
            {
                id: 5,
                valore: "Netflix"
            }

        ]

        await this.societaRepository.manager.save(SocietaEntity, societa);

    }

    async findRecapiti(body: number) {

        return await this.recapitiRepository.find({

            relations: ["tipo","user"],
            where: {

                user: {

                    id: body

                }

                

            }

        })

    }

    async findIndirizzo(body: number) {

        return await this.indirizzoRepository.find({

            relations: ["user"],
            where: {

                user: {

                    id: body

                }

                

            }

        })

    }


    removeRecapiti(body: number) {

        console.log(body);
        return this.recapitiRepository.softDelete({ id: body });

    }

    removeUser(body: number) {

        console.log(body);
        return this.usersRepository.softDelete({ id: body });

    }

    async getUser(body: number) {

        console.log(body);
        return await this.usersRepository.find({
            relations: [
                'societa'
            ], where: { id: body }
        });

    }

    async saveUser(body: UserDTO) {

        body.update = new Date();
        const singoloUser = {

            id: body.id,
            nome: body.nome,
            cognome: body.cognome,
            update: body.update,
            societa: {

                id: this.getSocietaId(body.societa),

            }

        }

        await this.usersRepository.save(singoloUser);

    }

    async saveRecapito(body: RecapitiDto) {

        console.log(body);
        console.log(body.id);
        const singoloRecapito = {

            id: body.id,
            valore: body.valore

        }

        await this.recapitiRepository.save(singoloRecapito);

    }

    async saveAddress(body: IndirizzoDTO) {

        let partialIndirizzo = [];

        if (body.id) {

            if (body.citta) {

                partialIndirizzo.push({

                    citta: body.citta,
                    indirizzo: body.indirizzo,
                    user:{
                        id:body.id
                    }
                })

            }
        } else {

            console.log("body.id")
            let id = await this.usersRepository.find({

                select: { id: true },
                order: { id: "DESC" },

            });

            let idUser = 0;
            if (id.length == 0) {

                idUser = 0

            } else {

                idUser = id[0].id

            }

            partialIndirizzo.push({

                citta: body.citta,
                indirizzo: body.indirizzo

            })


        }
        console.log("indirizzo",partialIndirizzo);
        await this.indirizzoRepository.manager.save(IndirizzoEntity, partialIndirizzo);

    }

    async generate(body: UserDTO[]) {

        for (const user of body) {

            const partialUser = {

                nome: user.nome,
                cognome: user.cognome,
                data: new Date(),
                update: new Date(),
                societa: {

                    id: Math.floor(Math.random() * 5) + 1,

                }

            }

            console.log(partialUser);
            await this.usersRepository.manager.save(UserEntity, partialUser);

        }

    }

    getTipoId(body: any) {

        switch (body) {

            case "Numero Cellulare":
                return 1;

            case "Numero Fisso":
                return 2;

            case "Fax ufficio":
                return 3;

            case "Email":
                return 4;

            case "Fax casa":
                return 5;

        }
    }

    getSocietaId(body: any) {

        console.log(body);
        switch (body) {

            case "Amazon":
                return 1;

            case "Google":
                return 2;

            case "Meta":
                return 3;

            case "Apple":
                return 4;

            case "Netflix":
                return 5;

        }

    }

    async createRecapito(body: UserDTO) {

        let partialRecapito = [];

        if (body.id) {

            if (body.recapiti.valore) {

                partialRecapito.push({

                    valore: body.recapiti.valore,
                    tipo: {

                        id: this.getTipoId(body.recapiti.tipo),

                    },
                    user: {

                        id: body.id

                    }

                })

            }
        } else {

            console.log("body.id")
            let id = await this.usersRepository.find({

                select: { id: true },
                order: { id: "DESC" },

            });

            let idUser = 0;
            if (id.length == 0) {

                idUser = 0

            } else {

                idUser = id[0].id

            }

            partialRecapito.push({

                valore: body.recapiti.valore,
                tipo: {

                    id: this.getTipoId(body.recapiti.tipo),

                },
                user: {

                    id: idUser

                }

            })


        }

        await this.recapitiRepository.manager.save(RecapitiEntity, partialRecapito);

    }
    async search(body: any) {

        body.skip *= 50
        this.data = this.usersRepository.find({

            relations: [

                'recapiti', 'recapiti.tipo', 'societa'
            ],
            where: [

                { nome: body.ricerca },
                { cognome: body.ricerca },
                { societa: { valore: body.ricerca } }

            ], take: 50, skip: body.skip, order: { id: 'asc' }

        })
        return await this.data;
    }

    async pdf(body: Object) {

        let data = await this.findAll(body);
        let users = []

        //prendo il giorno di oggi per creare le varie cartelle
        const todaysDate = new Date()
        const currentYear = todaysDate.getFullYear();
        const currentMonth = ("0" + (todaysDate.getMonth() + 1)).slice(-2);
        const currentDay = todaysDate.getDate();
        const today = `${currentYear}/${currentMonth}/${currentDay}`;

        for (const user of data) {

            users.push(
                {

                    id: user.id,
                    nome: user.nome,
                    cognome: user.cognome,
                    societa: user.societa.valore,
                    recapitiCount: user.recapiti.length,
                    data: moment(user.data).format("DD/MM/YYYY HH:mm"),
                    update: moment(user.update).format("DD/MM/YYYY HH:mm")

                }
            );
        }

        // Create a document
        const doc = new PDFDocument();

        let filePdf: PdfEntity = new PdfEntity();

        //creo un identificatore casuale
        filePdf.nomeFile = uuidv4();
        filePdf.tipoFile = "PDF";

        //controllo se esiste già un percorso simile sennò ne creo una con la data odierna
        if (!fs.existsSync(today)) {
            fs.mkdirSync(today, { recursive: true });
        }
        //imposto il path del file
        filePdf.dir = `${today}/${filePdf.nomeFile}.pdf`;

        // creo il pdf
        let pdfStream = doc.pipe(fs.createWriteStream(filePdf.dir));

        const table = {

            title: "Contatti",

            headers: [

                { label: "Id", property: 'id', width: 40, renderer: null },
                { label: "Nome", property: 'nome', width: 60, renderer: null },
                { label: "Cognome", property: 'cognome', width: 60, renderer: null },
                { label: "Società", property: 'societa', width: 60, renderer: null },
                { label: "N° Recapiti", property: 'recapitiCount', width: 80, renderer: null },
                { label: "Creazione", property: 'data', width: 80, renderer: null },
                { label: "Update", property: 'update', width: 80, renderer: null },

            ],
            // complex data
            datas: users,
        };

        doc.table(table, {

            width: 300,

        });
        doc.end();

        //creo una promise così che aspetti che finisca di generare il pdf
        const myPromise = new Promise((resolve) => {
            pdfStream.addListener('finish', function () {

                console.log("finito il pdf");
                resolve(filePdf.dir);

            });
            console.log("fatto");
        })
        //ritorno al controller il path del file pdf

        this.pdfRepository.save(filePdf);
        return myPromise.then(data => data)
    };

    async excelUsers(body: Object) {

        let data = await this.findAll(body);
        const todaysDate = new Date()
        const currentYear = todaysDate.getFullYear();
        const currentMonth = ("0" + (todaysDate.getMonth() + 1)).slice(-2);
        const currentDay = todaysDate.getDate();
        const today = `${currentYear}/${currentMonth}/${currentDay}`;
        let filePdf: PdfEntity = new PdfEntity();

        filePdf.nomeFile = uuidv4();
        filePdf.tipoFile = "Excel";

        //controllo se esiste già un percorso simile sennò ne creo una con la data odierna
        if (!fs.existsSync(today)) {
            fs.mkdirSync(today, { recursive: true });
        }
        //imposto il path del file
        filePdf.dir = `${today}/${filePdf.nomeFile}.xlsx`;

        //creo l'excel
        const workbook = new ExcelJS.Workbook();
        workbook.creator = 'Loris';
        workbook.lastModifiedBy = 'Loris';
        workbook.created = new Date(2023, 1, 30);
        workbook.modified = new Date();
        const worksheet = workbook.addWorksheet('Contatti', {
            views: [
            {state: 'frozen', ySplit: 1}
            ]
            });

        //inserisco le colonne
        worksheet.columns = [

            { header: 'Id', key: 'id' },
            { header: 'Nome', key: 'nome', width: 20 },
            { header: 'Cognome', key: 'cognome', width: 20 },
            { header: 'Società', key: 'societa', width: 20 },
            { header: 'N°recapiti', key: 'recapitiCount', width: 12 },
            { header: 'Creazione', key: 'data', width: 25 },
            { header: 'Update', key: 'update', width: 25 }

        ];

        //inserisco le righe
        for (const user of data) {

            const row = worksheet.addRow(
                {

                    id: user.id,
                    nome: user.nome,
                    cognome: user.cognome,
                    societa: user.societa.valore,
                    recapitiCount: user.recapiti.length,
                    data: moment(user.data).format("DD/MM/YYYY HH:mm"),
                    update: moment(user.update).format("DD/MM/YYYY HH:mm")

                }
            );
        }

        worksheet.columns.forEach((col) => {

            col.eachCell(function (cell, rowNumber) {

                cell.alignment = { horizontal: 'center', vertical: 'middle' };
                cell.height = 30;
                cell.font = {
                    color: "white"
                }
                cell.border = {

                    top: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    left: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    bottom: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    right: { style: 'thin', color: { argb: 'FFFFFFFF' } }

                };
                if (rowNumber == 1) {
                    cell.font = {
                        name: 'Arial Black',
                        family: 2,
                        size: 11,
                        italic: true,
                        bold: true,
                    };
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FF002BFF' }
                    };
                    
                    //coloro a righe alternate
                } else if (rowNumber % 2 == 0) {

                    cell.fill = {
                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FFD9DECC' },

                    };

                } else {

                    cell.fill = {
                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FF8AABFF' },

                    };

                }
            })
        });

        
        this.pdfRepository.save(filePdf);
        await workbook.xlsx.writeFile(filePdf.dir);
        return filePdf.dir;

    }


    async excelRecapiti(body: RecapitiDto) {

        let data = await this.findRecapiti(body.id);
        console.log(data);

        const todaysDate = new Date()
        const currentYear = todaysDate.getFullYear();
        const currentMonth = ("0" + (todaysDate.getMonth() + 1)).slice(-2);
        const currentDay = todaysDate.getDate();
        const today = `${currentYear}/${currentMonth}/${currentDay}`;
        let filePdf: PdfEntity = new PdfEntity();

        filePdf.nomeFile = uuidv4();
        filePdf.tipoFile = "Excel";

        //controllo se esiste già un percorso simile sennò ne creo una con la data odierna
        if (!fs.existsSync(today)) {
            fs.mkdirSync(today, { recursive: true });
        }
        //imposto il path del file
        filePdf.dir = `${today}/${filePdf.nomeFile}.xlsx`;

        //creo l'excel
        const workbook = new ExcelJS.Workbook();
        workbook.creator = 'Loris';
        workbook.lastModifiedBy = 'Loris';
        workbook.created = new Date(2023, 1, 30);
        workbook.modified = new Date();
        const worksheet = workbook.addWorksheet('Contatti', {
            views: [
            {state: 'frozen', ySplit: 1}
            ]
            });

        //inserisco le colonne
        worksheet.columns = [

            { header: 'Recapito', key: 'recapito',width: 50 },
            { header: 'Tipo', key: 'tipo', width: 50 },

        ];

        //inserisco le righe
        for (const user of data) {

            const row = worksheet.addRow(
                {

                    recapito: user.valore,
                    tipo: user.tipo.valore,

                }
            );
        }

        worksheet.columns.forEach((col) => {

            col.eachCell(function (cell, rowNumber) {

                cell.alignment = { horizontal: 'center', vertical: 'middle' };
                cell.height = 30;
                cell.font = {
                    color: "white"
                }
                cell.border = {

                    top: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    left: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    bottom: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    right: { style: 'thin', color: { argb: 'FFFFFFFF' } }

                };
                if (rowNumber == 1) {
                    cell.font = {

                        name: 'Arial Black',
                        family: 2,
                        size: 11,
                        italic: true,
                        bold: true,
                        
                    };
                    cell.fill = {

                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FF002BFF' }

                    };
                    
                    //coloro a righe alternate
                } else if (rowNumber % 2 == 0) {

                    cell.fill = {
                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FFD9DECC' },

                    };

                } else {

                    cell.fill = {
                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FF8AABFF' },

                    };

                }
            })
        });

        
        this.pdfRepository.save(filePdf);
        await workbook.xlsx.writeFile(filePdf.dir);
        return filePdf.dir;

    }


    async excelIndirizzi(body: IndirizzoDTO) {

        let data = await this.findIndirizzo(body.id);
        console.log(data);

        const todaysDate = new Date()
        const currentYear = todaysDate.getFullYear();
        const currentMonth = ("0" + (todaysDate.getMonth() + 1)).slice(-2);
        const currentDay = todaysDate.getDate();
        const today = `${currentYear}/${currentMonth}/${currentDay}`;
        let filePdf: PdfEntity = new PdfEntity();

        filePdf.nomeFile = uuidv4();
        filePdf.tipoFile = "Excel";

        //controllo se esiste già un percorso simile sennò ne creo una con la data odierna
        if (!fs.existsSync(today)) {
            fs.mkdirSync(today, { recursive: true });
        }
        //imposto il path del file
        filePdf.dir = `${today}/${filePdf.nomeFile}.xlsx`;

        //creo l'excel
        const workbook = new ExcelJS.Workbook();
        workbook.creator = 'Loris';
        workbook.lastModifiedBy = 'Loris';
        workbook.created = new Date(2023, 1, 30);
        workbook.modified = new Date();
        const worksheet = workbook.addWorksheet('Contatti', {
            views: [
            {state: 'frozen', ySplit: 1}
            ]
            });

        //inserisco le colonne
        worksheet.columns = [

            { header: 'Città', key: 'citta', width: 50 },
            { header: 'Indirizzo', key: 'indirizzo', width: 100 },

        ];

        //inserisco le righe
        for (const user of data) {

            const row = worksheet.addRow(
                {

                    citta: user.citta,
                    indirizzo: user.indirizzo,

                }
            );
        }

        worksheet.columns.forEach((col) => {

            col.eachCell(function (cell, rowNumber) {

                cell.alignment = { horizontal: 'center', vertical: 'middle' };
                cell.height = 30;
                cell.font = {
                    color: "white"
                }
                cell.border = {

                    top: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    left: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    bottom: { style: 'thin', color: { argb: 'FFFFFFFF' } },
                    right: { style: 'thin', color: { argb: 'FFFFFFFF' } }

                };
                if (rowNumber == 1) {
                    cell.font = {

                        name: 'Arial Black',
                        family: 2,
                        size: 11,
                        italic: true,
                        bold: true,
                        
                    };
                    cell.fill = {

                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FF002BFF' }

                    };
                    
                    //coloro a righe alternate
                } else if (rowNumber % 2 == 0) {

                    cell.fill = {
                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FFD9DECC' },

                    };

                } else {

                    cell.fill = {
                        type: 'pattern',
                        pattern: 'darkTrellis',
                        bgColor: { argb: 'FF8AABFF' },

                    };

                }
            })
        });

        
        this.pdfRepository.save(filePdf);
        await workbook.xlsx.writeFile(filePdf.dir);
        return filePdf.dir;

    }

}
  