import { SocietaDTO, SocietaInterface } from "src/societa/societa.dto";
import { BaseInterface, RecapitiDto, RecapitiInterface} from "../recapiti/recapiti.dto"

export interface UserInterface extends BaseInterface{
  nome: string;
  cognome: string;
  recapiti: RecapitiInterface;
  societa: SocietaInterface;
  data:Date;
  update:Date;
}

export class UserDTO implements UserInterface{

  constructor(){
    this.id=0;
    this.nome="0";
    this.cognome="";
    this.recapiti= new RecapitiDto[''];
    this.societa= new SocietaDTO[''];
  }

  id: number;
  nome: string;
  cognome: string;
  recapiti: RecapitiInterface;
  societa: SocietaInterface;
  data:Date;
  update:Date;

}
