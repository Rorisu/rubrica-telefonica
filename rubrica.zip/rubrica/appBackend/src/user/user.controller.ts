import { Body, Controller, Get, Post, Res, StreamableFile } from '@nestjs/common';
import { UserService } from './user.service';
import { RecapitiDto } from 'src/recapiti/recapiti.dto';
import { UserDTO } from './user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PdfEntity } from 'src/pdf/pdf.entity';
import { existsSync } from 'fs';
import { IndirizzoDTO } from 'src/indirizzo/indirizzo.dto';
const fs = require('fs');

@Controller()
export class UserController {

    skip: number;
    constructor(private userService: UserService,
        @InjectRepository(PdfEntity)
        private pdfRepository: Repository<PdfEntity>) { }

    @Post('/form')
    async create(body: UserDTO) {

        await this.userService.create(body);
        return this.userService.findAll(this.skip)

    }

    @Post('/form/generate')
    async generate(@Body() body: UserDTO[]) {

        console.log("body: ", body);
        await this.userService.generate(body);
        return this.userService.findAll(this.skip);

    }

    @Get("/input")
    async findTipo() {

        return this.userService.findTipi();

    }

    @Get("/societa")
    async findSocieta() {

        return this.userService.getSocieta();

    }

    @Post('/form/dati')
    async visualizza(@Body() body: number) {

        this.skip = body;
        return this.userService.findAll(this.skip)

    }

    @Get('/form/count')
    async count() {

        return this.userService.count();

    }

    @Post('/form/recapiti')
    async recapiti(@Body() body: RecapitiDto) {

        return this.userService.findRecapiti(body.id);

    }

    @Post('/form/recapiti/remove')
    async removeRecapiti(@Body() body: RecapitiDto) {
        return this.userService.removeRecapiti(body.id);
    }

    @Post('/form/remove')
    async removeUser(@Body() body: UserDTO) {
        return this.userService.removeUser(body.id);
    }

    @Post('/form/user')
    async getUser(@Body() body: UserDTO) {

        return this.userService.getUser(body.id);

    }

    @Post('/search')
    async search(@Body() body: string) {

        console.log("search", body);
        return this.userService.search(body);

    }

    @Post('/form/save')
    async saveUser(@Body() body: UserDTO) {

        console.log("save body:", body)
        if (!body.id) {

            this.create(body);

        } else {

            return this.userService.saveUser(body);
        }

    }

    @Post('/form/saveRecapito')
    async createRecapito(@Body() body: UserDTO) {

        console.log("recapiti", body)
        return this.userService.createRecapito(body);

    }

    @Post('/form/save/recapito')
    async saveRecapito(@Body() body: RecapitiDto) {

        console.log(body);
        return this.userService.saveRecapito(body);

    }

    @Post('/form/saveAddress')
    async saveAddress(@Body() body: IndirizzoDTO) {

        console.log(body);
        return this.userService.saveAddress(body);

    }

    @Post('/pdf')
    async pdf(@Body() body: UserDTO[], @Res() res) {

        let path: any = await this.userService.pdf(body);
        console.log("path:", path);
        var stats = fs.statSync(path)
        //"anno/mese/giorno/8aa60187-2690-4d06-949b-ff2d6363814c.pdf"
        var fileSizeInBytes = stats.size;
        console.log(fileSizeInBytes);
        if (existsSync(path)) {
            console.log('file exists');
        } else {
            console.log('file not found!');
        }
        return res.download(path);
    }

    @Post('/user/excel')
    async excelUsers(@Body() body: UserDTO[], @Res() res) {

        let path: any = await this.userService.excelUsers(body);
        console.log("path:", path);
        var stats = fs.statSync(path)
        //"anno/mese/giorno/8aa60187-2690-4d06-949b-ff2d6363814c.pdf"
        var fileSizeInBytes = stats.size;
        console.log(fileSizeInBytes);
        if (existsSync(path)) {
            console.log('file exists');
        } else {
            console.log('file not found!');
        }
        return res.download(path);
    }

    @Post('/recapiti/excel')
    async excelRecapiti(@Body() body: RecapitiDto, @Res() res) {

        let path: any = await this.userService.excelRecapiti(body);
        console.log("path:", path);
        var stats = fs.statSync(path)
        //"anno/mese/giorno/8aa60187-2690-4d06-949b-ff2d6363814c.pdf"
        var fileSizeInBytes = stats.size;
        console.log(fileSizeInBytes);
        if (existsSync(path)) {
            console.log('file exists');
        } else {
            console.log('file not found!');
        }
        return res.download(path);
    }

    @Post('/indirizzi/excel')
    async excelIndirizzi(@Body() body: IndirizzoDTO, @Res() res) {

        let path: any = await this.userService.excelIndirizzi(body);
        console.log("path:", path);
        var stats = fs.statSync(path)
        //"anno/mese/giorno/8aa60187-2690-4d06-949b-ff2d6363814c.pdf"
        var fileSizeInBytes = stats.size;
        console.log(fileSizeInBytes);
        if (existsSync(path)) {
            console.log('file exists');
        } else {
            console.log('file not found!');
        }
        return res.download(path);
    }
}   