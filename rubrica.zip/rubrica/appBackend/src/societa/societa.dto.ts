import { BaseInterface } from "src/recapiti/recapiti.dto";

  
  export interface SocietaInterface extends BaseInterface{
  
    valore:string;
  
  }
  
  export class SocietaDTO implements SocietaInterface{
  
    id:number;
    valore:string;
  
  }
  
