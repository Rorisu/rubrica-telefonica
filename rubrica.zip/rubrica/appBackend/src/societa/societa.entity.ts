import { BaseEntity } from 'src/baseEntities/base.entity';
import { UserEntity } from 'src/user/user.entity';
import { Entity, Column, OneToMany, OneToOne } from 'typeorm';

@Entity()
export class SocietaEntity extends BaseEntity{

  @Column()
  valore: string;  

  @OneToOne(() => UserEntity, (obj) => obj.societa)
  user: UserEntity[]
  
}
