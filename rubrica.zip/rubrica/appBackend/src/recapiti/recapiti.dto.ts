import { TipoDTO, TipoInterface } from "src/tipo/tipo.dto";

export interface BaseInterface{
    id:number;
  }
  
  export interface RecapitiInterface extends BaseInterface{

    length: number;
    valore:string;
    tipo: TipoInterface;

  
  }
  
  export class RecapitiDto implements RecapitiInterface{
  
    id:number;
    valore:string;
    tipo:TipoDTO;
    length:number;
  
  }
  
