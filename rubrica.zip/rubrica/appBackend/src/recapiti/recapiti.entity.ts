import { BaseEntityIncrement } from 'src/baseEntities/baseIncrement.entity';
import { TipoEntity } from 'src/tipo/tipo.entity';
import { UserEntity } from 'src/user/user.entity';
import { Entity, Column, ManyToOne } from 'typeorm';

@Entity()
export class RecapitiEntity extends BaseEntityIncrement{

  @Column()
  valore: string;

  @ManyToOne(() => UserEntity) 
  user: UserEntity;

  @ManyToOne(() => TipoEntity) 
  tipo: TipoEntity;
  
}
