import { Entity, PrimaryGeneratedColumn,} from "typeorm";
import { BaseEntityDate } from "./baseDate.entity";

@Entity()
export class BaseEntity extends BaseEntityDate{
  @PrimaryGeneratedColumn()
  id: number;

}