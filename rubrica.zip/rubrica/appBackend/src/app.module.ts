import { Module } from '@nestjs/common';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RecapitiEntity } from './recapiti/recapiti.entity';
import { TipoEntity } from './tipo/tipo.entity';
import { UserModule } from './user/user.module';
import { UserEntity } from './user/user.entity';
import { SocietaEntity } from './societa/societa.entity';
import { PdfEntity } from './pdf/pdf.entity';
import { IndirizzoEntity } from './indirizzo/indirizzo.entity';
@Module({
  imports: [
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', '/src'),
    }),
      TypeOrmModule.forRoot({
        type: 'postgres',
        username: 'postgres',
        password: 'prova',
        port: 54321,
        database: 'postgres',
        synchronize: true,
        logging: false,
        autoLoadEntities: true,
        entities:[UserEntity,TipoEntity,RecapitiEntity,SocietaEntity,PdfEntity,IndirizzoEntity]
      }),
      UserModule
  ],
})
export class AppModule {}