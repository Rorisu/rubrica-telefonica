import { BaseEntity } from 'src/baseEntities/base.entity';
import { RecapitiEntity } from 'src/recapiti/recapiti.entity';
import { Entity, Column,OneToMany } from 'typeorm';

@Entity()
export class TipoEntity extends BaseEntity{

  @Column()
  valore: string;  

  @OneToMany(() => RecapitiEntity, (obj) => obj.tipo)
  recapiti: RecapitiEntity[]

}