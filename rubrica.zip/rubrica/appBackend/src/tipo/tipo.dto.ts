import { BaseInterface } from "src/recapiti/recapiti.dto";

  
  export interface TipoInterface extends BaseInterface{
  
    valore:string;
  
  }
  
  export class TipoDTO implements TipoInterface{
  
    id:number;
    valore:string;
  
  }
  