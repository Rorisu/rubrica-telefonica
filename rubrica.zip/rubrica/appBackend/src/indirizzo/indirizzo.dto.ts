import { BaseInterface } from "src/recapiti/recapiti.dto";

  
  export interface IndirizzoInterface extends BaseInterface{
  
    citta:string;
    indirizzo:string;
  
  }
  
  export class IndirizzoDTO implements IndirizzoInterface{
  
    id:number;
    citta:string;
    indirizzo:string;
  
  }
  
