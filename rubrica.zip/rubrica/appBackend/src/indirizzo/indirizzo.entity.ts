import { BaseEntity } from 'src/baseEntities/base.entity';
import { UserEntity } from 'src/user/user.entity';
import { Entity, Column, ManyToOne } from 'typeorm';

@Entity()
export class IndirizzoEntity extends BaseEntity{

  @Column()
  citta: string;  

  @Column()
  indirizzo: string;  

  @ManyToOne(() => UserEntity) 
  user: UserEntity;
  
}
