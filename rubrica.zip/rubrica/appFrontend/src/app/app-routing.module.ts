import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormComponent } from './form/form.component';
import { TabellaComponent } from './tabella/tabella.component';

const routes: Routes = [
  {path: "input", component: FormComponent, title: "Input"},
  {path: "", component: TabellaComponent, title: "Tabella"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
