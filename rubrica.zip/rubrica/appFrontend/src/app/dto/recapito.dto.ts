

export interface UserInterface{
  id: number
  valore: string;
  tipo: string;
}

export class RecapitoDto implements UserInterface{

  constructor(){
    this.id=0
    this.valore="";
    this.tipo="";
  }

  id:number;
  valore: string;
  tipo: string;

}
