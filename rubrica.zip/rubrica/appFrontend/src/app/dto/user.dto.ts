/*import { generalInterface, TipoDTO, TipoInterface } from "./nazione.dto"
import { NumeroDTO, NumeroInterface } from "./numero.dto"

export interface UserInterface extends generalInterface{
  nome: number;
  cognome: string;
  tipo: TipoInterface;
  numero:
}

export class UserDTO implements UserInterface{

  constructor(){
    this.id=0;
    this.nome=0;
    this.cognome="";
    this.nazione= new TipoInterface();
  }

  id: number;
  nome: number;
  cognome: string;
  nazione: TipoInterface;

}*/
