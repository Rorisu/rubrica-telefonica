import { Component, EventEmitter, Output } from '@angular/core';
import { TabellaComponent } from './tabella/tabella.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  id: number = 0;
  data:any;

  title = 'appFrontend';
  set(id: number) {
    this.id = id;
    console.log(this.id)
  }
  output(data: any) {
    console.log(this.data= data);
  }
}
