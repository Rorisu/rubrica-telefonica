import { AfterViewInit, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { HttpService, PeriodicElement } from '../http.service';
import * as FileSaver from 'file-saver';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-tabella',
  templateUrl: './tabella.component.html',
  styleUrls: ['./tabella.component.css']
})
export class TabellaComponent implements OnInit, OnChanges {

  id: number = 0;
  ricerca: string = '';
  skip: number = 0;
  currentPage: number = this.skip + 1;
  totalPages: number = 0;
  minimo: boolean = false;
  massimo: boolean = true;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  dataSource = new MatTableDataSource<PeriodicElement>([]);
  @ViewChild(MatSort) sort!: MatSort;

  displayedColumns = ['id', 'nome', 'cognome', 'societa', 'count', 'creazione', 'update', 'modifica', 'rimuovi'];

  constructor(private httpService: HttpService) {
  }

  @Output() newItemEvent = new EventEmitter<number>();
  @Input() public data: any;

  ngOnChanges(changes: SimpleChanges): void {

    this.ngOnInit();

  }

  ngOnInit(): void {

    this.httpService.tabella({ ricerca: this.ricerca, skip: this.skip }).subscribe((data: PeriodicElement[]) => {

      this.dataSource.data = data;
      this.dataSource.sort = this.sort;
      console.log(data);

      this.httpService.count().subscribe((data) => {

        this.totalPages = Math.ceil(Number(data) / 50);

      });

    });

  }

  seleziona(id: number) {

    this.id = id;
    this.newItemEvent.emit(id);
    this.httpService.setId(id);

  }

  rimuovi(id: any) {

    this.httpService.removeUser({ id: id }).subscribe(() => {

      this.ngOnInit();

    });

  }

  confirmRemoveUser(id: any) {

    if (confirm("confermi di voler cancellare l'utente?")) {

      this.rimuovi(id)

    }

  }

  confirmEditUser(id: any) {

    if (confirm("confermi di voler modificare l'utente?")) {

      this.seleziona(id)

    }
  }

  addUser(id: number) {

    this.httpService.setId(id);

  }

  search() {
    this.httpService.search({ ricerca: this.ricerca, skip: this.skip }).subscribe((data: any) => {

      console.log(data);
      this.dataSource.data = data;
      this.dataSource.sort = this.sort;

    });
  }

  skipLeft() {
    this.massimo = true;
    this.skip -= 1;
    this.currentPage -= 1;
    if (this.currentPage == 1) {
      this.minimo = false;
    }
    this.httpService.tabella({ ricerca: this.ricerca, skip: this.skip }).subscribe((data: PeriodicElement[]) => {

      this.dataSource.data = data;
      this.dataSource.sort = this.sort;

    });
  }
  skipRight() {

    this.minimo = true
    this.skip += 1;
    this.currentPage += 1;

    if (this.currentPage == this.totalPages) {

      this.massimo = false;

    }

    this.httpService.tabella({ ricerca: this.ricerca, skip: this.skip }).subscribe((data: PeriodicElement[]) => {

      console.log(data);
      this.dataSource.data = data;
      this.dataSource.sort = this.sort;

    });
  }

  createPdf() {

    this.httpService.pdf({ ricerca: this.ricerca, skip: this.skip }).subscribe((data) => {

      console.log(data);
      FileSaver.saveAs(data);

    })
  }

  createExcel() {

    this.httpService.excel({ ricerca: this.ricerca, skip: this.skip }).subscribe((data) => {

      console.log(data);
      FileSaver.saveAs(data);

    })

  }

}
