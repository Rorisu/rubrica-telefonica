import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { HttpService, PeriodicElement } from '../http.service';
import { RecapitoDto } from '../dto/recapito.dto';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})

export class FormComponent implements OnInit, OnChanges {

  public counterChanges: number = 0;
  public recapitiBool: boolean = false;
  public datiTabella: Array<any> = [{}]
  public tipoInput: Array<any> | undefined;
  public tipo: Array<any> | undefined;
  public societa: Array<any> | undefined;
  public idRecapiti: Array<any> = []
  public tipoRecapiti: Array<any> = []

  schedaForm: FormGroup;


  @Input() public id: any;
  @Output() output = new EventEmitter<any>();

  constructor(
    private fb: FormBuilder,
    private httpService: HttpService,
  ) {

    this.schedaForm = new FormGroup({
      firstName: new FormControl(),
      lastName: new FormControl(),
      societa: new FormControl(),
      citta: new FormControl(),
      indirizzo: new FormControl(),
      valori: this.fb.array([]),
      recapito: new FormGroup({
        tipo: new FormControl(),
        valore: new FormControl()
      }),
      recapiti: new FormGroup({}),
    })

  }

  ngOnChanges() {

    this.mostraRecapito()
    this.recapitiBool = true;
    this.getUser(this.id);

  }

  ngOnInit(): void {

    if (this.httpService.getId() != 0) {

      this.id = this.httpService.getId();
      this.ngOnChanges();

    }

    this.httpService.getTipo().subscribe((data) => {

      this.tipo = data;

      this.httpService.getSocieta().subscribe((data) => {

        this.societa = data;
      }
      );
    })
  }

  formValue(): void {
    console.log(this.schedaForm.value);
  }

  get rolesFieldAsFormArray(): any {

    return this.schedaForm.get('valori') as FormArray;

  }

  generateUsers() {

    this.httpService.generateUsers(this.schedaForm.value.valori);
    this.output.emit("dati");

  }

  valori(tipo: any) {

    //prendo id tipo
    switch (tipo) {

      case "Numero Cellulare":
        tipo = 1;
        break;
      case "Numero Fisso":
        tipo = 2;
        break;
      case "Fax ufficio":
        tipo = 3;
        break;
      case "Email":
        tipo = 4;
        break;
      case "Fax casa":
        tipo = 5;
        break;
    }

    return this.fb.group({
      valore: this.fb.control(''),
      tipo: tipo
    });
  }

  remove(i: number): void {

    this.rolesFieldAsFormArray.removeAt(i);

  }

  addControl(tipo: string): void {

    this.rolesFieldAsFormArray.push(this.valori(tipo));

  }

  mostraRecapito() {

    const _formRecapiti = this.schedaForm.get('recapiti') as FormGroup;
    this.datiTabella = [];

    this.httpService.mostraRecapito({ id: this.id }).subscribe((data: any[]) => {

      for (const _recapito of data) {
        _formRecapiti.addControl(`recapito_${_recapito.id}`, new FormControl(_recapito.valore));
        this.datiTabella.push({ id: _recapito.id, tipo: _recapito.tipo.valore });

      }

    })

  }

  modificaRecapito(id: number) {

    console.log(this.schedaForm.get(`recapiti.recapito_${id}`)?.value);
    let dati = {
      id: id,
      valore: this.schedaForm.get(`recapiti.recapito_${id}`)?.value
    }
    console.log(dati);
    this.httpService.modificaRecapito(dati).subscribe((data) => {

      console.log(data);

    })

  }

  removeRecapito(id: number) {

    this.httpService.removeRecapito({ id: id }).subscribe((data) => {

      this.mostraRecapito();
      this.output.emit(id);

    })


  }

  saveUser() {

    let dati = {
      id: this.id,
      nome: this.schedaForm.value.firstName,
      cognome: this.schedaForm.value.lastName,
      societa: this.schedaForm.value.societa
    }

    this.httpService.save(dati).subscribe(() => {

      this.output.emit(dati);
      this.mostraRecapito();

    });

  }

  getUser(id: number) {

    this.httpService.getUser({ id: id }).subscribe((data) => {

      console.log(data);
      this.schedaForm.get('firstName')?.setValue(data[0].nome)
      this.schedaForm.get('lastName')?.setValue(data[0].cognome)
      this.schedaForm.get('societa')?.setValue(data[0].societa.valore)

    })
  }

  confirmEditUser() {

    if (confirm("confermi di voler creare l'utente?")) {

      this.saveUser();

    }
  }

  //modifica il recapito già creato
  confirmEditRecapito(id: number) {

    if (confirm("confermi di voler modificare il recapito?")) {

      this.modificaRecapito(id)

    }

  }

  confirmRemoveRecapito(id: number) {

    if (confirm("confermi di voler eliminare il recapito?")) {

      this.removeRecapito(id);

    }

  }

  confirmGenerateUser() {

    if (confirm("confermi di voler generare 100 utenti casuali?")) {

      this.generateUsers();

    }
  }

  confirmCreateRecapito() {

    if (confirm("confermi di voler aggiungere un recapito?")) {

      this.createRecapito();

    }

  }

  confirmCreateAddress() {

    if (confirm("confermi di voler salvare l'indirizzo?")) {

      this.createAddress();

    }

  }
  createRecapito() {

    let dati = {

      id: this.id,
      recapiti: this.schedaForm.get('recapito')?.value

    }

    this.httpService.saveRecapito(dati).subscribe((data) => {

      console.log(data);
      this.output.emit(dati);
      this.mostraRecapito();

    });

  }

  createAddress() {

    let dati = {

      id: this.id,
      citta: this.schedaForm.get('citta')?.value,
      indirizzo: this.schedaForm.get('indirizzo')?.value

    }
    console.log(dati);

    this.httpService.saveAddress(dati).subscribe((data) => {

      console.log(data);

    });

  }

  createExcel() {

    this.httpService.excelRecapiti({ id: this.id }).subscribe((data) => {

      console.log(data);
      FileSaver.saveAs(data);

    })

  }
}

