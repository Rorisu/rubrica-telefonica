import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RecapitoDto } from './dto/recapito.dto';

@Injectable({
  providedIn: 'root'
})

export class HttpService {

  public user: Array<object> = []
  public nomi: Array<string> = ["Leonardo", "Francesco", "Alessandro", "Loris", "Matteo", "David", "Luca", "Marco", "Diego", "Mario", "Lorenzo", "Gabriele", "Cristiano", "Lorenzo", "Giorgio", "Bianca", "Elisa", "Giulia", "Alessia"]
  public cognomi: Array<string> = ["Rossi", "Ferrari", "Russo", "Bianchi", "Romano", "Gallo", "Costa", "Fontana", "Conti", "Esposito", "Ricci", "Bruno", "Rizzo", "Moretti", "De Luca", "Marino", "Greco", "Barbieri", "Lombardi", "Morelli"]
  public id: number = 0;


  constructor(private http: HttpClient) {

  }
  generateUsers(type: any) {

    for (let i = 0; i < 100; i++) {

      const nome = { nome: this.nomi[Math.floor(Math.random() * 19)], cognome: this.cognomi[Math.floor(Math.random() * 20)], type: type };
      this.user.push(nome);

    }

    return this.http.post('http://localhost:3000/form/generate', this.user).subscribe(() => {
    });

  }

  save(dati: any) {

    console.log(dati);
    return this.http.post<any>('http://localhost:3000/form/save', dati);

  }

  getTipo() {

    return this.http.get<any>('http://localhost:3000/input');

  }

  getSocieta() {

    return this.http.get<any>('http://localhost:3000/societa');

  }

  tabella(skip: any): Observable<any> {

    return this.http.post('http://localhost:3000/form/dati', skip)

  }

  count() {

    return this.http.get('http://localhost:3000/form/count')

  }

  mostraRecapito(id: any) {

    return this.http.post<RecapitoDto[]>('http://localhost:3000/form/recapiti', id);

  }

  removeRecapito(id: any) {

    console.log(id)
    return this.http.post<any>('http://localhost:3000/form/recapiti/remove', id);

  }

  modificaRecapito(id: any) {

    console.log(id)
    return this.http.post<any>('http://localhost:3000/form/save/recapito', id);

  }

  removeUser(id: any) {

    return this.http.post<any>('http://localhost:3000/form/remove', id);

  }

  getUser(id: any) {

    return this.http.post<any>('http://localhost:3000/form/user', id);

  }

  setId(id: number) {

    this.id = id;

  }

  getId() {

    return this.id;

  }

  saveRecapito(dati: any) {
    console.log(dati);
    return this.http.post<any>('http://localhost:3000/form/saveRecapito', dati);
  }

  saveAddress(dati: any) {
    console.log(dati);
    return this.http.post<any>('http://localhost:3000/form/saveAddress', dati);
  }


  search(ricerca: any) {

    return this.http.post('http://localhost:3000/search', ricerca)

  }

  pdf(data: any) {

    return this.http.post('http://localhost:3000/pdf', data, { responseType: 'blob' })

  }

  excel(data: any) {
    return this.http.post('http://localhost:3000/user/excel', data, { responseType: 'blob' })
  }

    excelRecapiti(data: any) {
    return this.http.post('http://localhost:3000/recapiti/excel', data, { responseType: 'blob' })
  }
}

export interface PeriodicElement {
  id: number;
  nome: string;
  cognome: string;
  type: string;
  email: string;
  number: number;
}

export interface TipoElement {
  valore: string;
  tipo: string;
}
